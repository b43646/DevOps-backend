from pyvirtualdisplay import Display  
  
display = Display(visible=0, size=(1024, 768))  
def start():  
    display.start()  
  
def stop():  
    display.stop() 
